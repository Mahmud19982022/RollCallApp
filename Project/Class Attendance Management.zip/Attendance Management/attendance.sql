CREATE DATABASE ST_LOGIN;

CREATE  TABLE attendance
(
StudentId VARCHAR(50) PRIMARY KEY,
StudentName VARCHAR(50),
Status   VARCHAR(50)

);

SELECT * FROM attendance



