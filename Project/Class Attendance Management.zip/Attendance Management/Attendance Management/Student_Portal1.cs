﻿/*
using System;

namespace Attendance_Management
{

    internal class Student_Portal
    {

        internal void Show()
        {
            //throw new System.Exception();
        }


    }

}*/